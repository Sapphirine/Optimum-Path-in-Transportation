
# coding: utf-8

# In[2]:


f=file("airport.csv")
s=f.read()
f.close()
lines=s.split('\n')
vertex=[]
for i in range(1,len(lines)-1):
    vertex.append(lines[i].split(','))


# In[3]:


f=file("requirement.txt")
s=f.read()
f.close()
lines=s.split('\n')
origin=lines[2].split(':')[1]
dest=lines[3].split(':')[1]
for i in vertex:
    if origin==i[1]:
        origin=i[0]
    if dest==i[1]:
        dest=i[0]

graph=[]
for i in vertex:
    line=[]
    for j in vertex:
        line.append(999999)
    graph.append(line)


# In[4]:


f=file("data.csv")
s=f.read()
f.close()
lines=s.split('\n')
for i in range(1,len(lines)-1):
    c=lines[i].split(',')
    graph[int(c[0])][int(c[1])]=float(c[2])


# In[5]:


for i in range(len(graph)):
    graph[i][i]=0


# In[6]:


def dijkstra(graph,src):
    if graph is None:
        return None
    nodes = [i for i in range(len(graph))]
    visited=[] 
    if src in nodes:
        visited.append(src)
        nodes.remove(src)
    else:
        return None
    distance={src:0}
    for i in nodes:
        distance[i]=graph[src][i]  
    path={src:{src:[]}} 
    k=pre=src
    while nodes:
        mid_distance=999999
        for v in visited:
            for d in nodes:
                new_distance = graph[src][v]+graph[v][d]
                if new_distance <= mid_distance:
                    mid_distance=new_distance
                    graph[src][d]=new_distance
                    k=d
                    pre=v
        distance[k]=mid_distance
        path[src][k]=[i for i in path[src][pre]]
        path[src][k].append(k)
        visited.append(k)
        nodes.remove(k)
    return distance,path


# In[7]:


distance,path=dijkstra(graph,int(origin))


# In[20]:


path_name=[vertex[int(origin)][1]]
for j in path[int(origin)][int(dest)]:
    path_name.append(vertex[j][1])


# In[21]:


print distance[int(dest)]
print path_name

