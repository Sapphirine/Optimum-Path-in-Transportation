python input_requirement.py
echo "Processing input..."
python predict_file_form.py
echo "Please run pyspark using the code in predict.py"
echo "Done? (y/n)"
read flag
if [ "$flag" = "y" -o "$flag" = "Y" ]; then
    echo "Processing predicted data and forming graph..."
    python predicted_clean.py
    python Final_form.py
    echo "Searching for the shortest path..."
    echo "The optimal choice is:"
    python GRAPH_REAL.py
else
    exit
fi
