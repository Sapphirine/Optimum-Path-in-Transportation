
# coding: utf-8

# In[25]:


f=file('predicted_clean.csv')
s=f.read()
f.close()


# In[26]:


lines=s.split('\n')


# In[27]:


lis=[]
for i in range(1,len(lines)-1):
    c=lines[i].split(',')
    while (len(c)<6) :
        c.append('1')
    lis.append(c)


# In[29]:


f=file("requirement.txt")
s=f.read()
f.close()
lines=s.split('\n')
model=lines[4].split(':')[1]
if model=='3' :
    p=[1,1,1,9000,0]
elif model=='0' :
    p=[1,1,1,0,60]
elif model=='4' :
    p=[2,0,0,0,0]
elif model=='1':
    p=[1,1,1,0,0]
elif model=='2':
    p=[0,0,2,0,0]
elif model=='5':
    p=[1,1.5,1,150,60]


# In[30]:
lis[55]

for i in lis:
    k=p[0]*int(float(i[2]))+(int(float(i[3]))**p[1]+int(float(i[4]))**p[2])/2+p[3]*int(float(i[5]))+p[4]
    i.append(str(k))


# In[31]:


f=file('data.csv','w')
f.write('origin,dest,weight\n')
for i in lis:
    c=','.join([i[0],i[1],i[6]])
    f.write(c+'\n')
f.close()

