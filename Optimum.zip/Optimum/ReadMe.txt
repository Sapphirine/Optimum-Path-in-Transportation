If it doesn't work like the vedio shows, this may due to this folder doesn't contain the predicted files which we have obtained. 

You need to run Run.sh firstly and input your requirement, then you need to copy the code in predict.py and run it by just pasting it to the shell of pyspark (You should run pyspark from this folder, otherwise it may report some error)to get predicted files.
