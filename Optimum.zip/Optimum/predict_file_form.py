
# coding: utf-8

# In[1]:


f=file('requirement.txt')
s=f.read()
f.close()
lines=s.split('\n')
month=lines[0].split(':')[1]
dow=lines[1].split(':')[1]


# In[2]:


f=file('airlines_elapse.csv')
s=f.read()
f.close()
lines=s.split('\n')
airlines=[]
for i in lines:
    c=i.split(',')
    airlines.append(c)

f=file('predict_elapse.csv','w')
for i in airlines:
    try:
        c=[month,dow,i[0],i[1],'0']
        c=','.join(c)
        f.write(c+'\n')
    except:
        continue
f.close()


# In[3]:


f=file('airlines_arrive.csv')
s=f.read()
f.close()
lines=s.split('\n')
airlines=[]
for i in lines:
    c=i.split(',')
    airlines.append(c)

f=file('predict_arrive.csv','w')
for i in airlines:
    try:
        c=[month,dow,i[0],i[1],'0']
        c=','.join(c)
        f.write(c+'\n')
    except:
        continue
f.close()


# In[4]:


f=file('airlines_depart.csv')
s=f.read()
f.close()
lines=s.split('\n')
airlines=[]
for i in lines:
    c=i.split(',')
    airlines.append(c)

f=file('predict_depart.csv','w')
for i in airlines:
    try:
        c=[month,dow,i[0],i[1],'0']
        c=','.join(c)
        f.write(c+'\n')
    except:
        continue
f.close()


# In[5]:


f=file('airlines_delay.csv')
s=f.read()
f.close()
lines=s.split('\n')
airlines=[]
for i in lines:
    c=i.split(',')
    airlines.append(c)

f=file('predict_delay.csv','w')
for i in airlines:
    try:
        c=[month,dow,i[0],i[1],'0']
        c=','.join(c)
        f.write(c+'\n')
    except:
        continue
f.close()


# In[6]:


f=file('airlines_cancel.csv')
s=f.read()
f.close()
lines=s.split('\n')
airlines=[]
for i in lines:
    c=i.split(',')
    airlines.append(c)

f=file('predict_cancel.csv','w')
for i in airlines:
    try:
        c=[month,dow,i[0],i[1],'0']
        c=','.join(c)
        f.write(c+'\n')
    except:
        continue
f.close()

