
# coding: utf-8

# In[1]:


f=file("predicted_elapse.csv")
s=f.read()
f.close()
lines=s.split('\n')


# In[2]:


edges=[]
for i in range(1,len(lines)-1):
    c=lines[i].split(',')
    airline=[str(int(float(c[3]))),str(int(float(c[4][0:-2]))),c[5]]
    edges.append(airline)


# In[3]:


f=file("predicted_depart.csv")
s=f.read()
f.close()
lines=s.split('\n')


# In[4]:


for i in range(1,len(lines)-1):
    c=lines[i].split(',')
    for j in edges:
        if (j[0]==str(int(float(c[3])))) and (j[1]==str(int(float(c[4][0:-2])))):
            j.append(c[5])


# In[5]:


f=file("predicted_arrive.csv")
s=f.read()
f.close()
lines=s.split('\n')


# In[6]:


for i in range(1,len(lines)-1):
    c=lines[i].split(',')
    for j in edges:
        if (j[0]==str(int(float(c[3])))) and (j[1]==str(int(float(c[4][0:-2])))):
            j.append(c[5])


# In[7]:


f=file("predicted_cancel.csv")
s=f.read()
f.close()
lines=s.split('\n')


# In[8]:


for i in range(1,len(lines)-1):
    c=lines[i].split(',')
    for j in edges:
        if (j[0]==str(int(float(c[3])))) and (j[1]==str(int(float(c[4][0:-2])))):
            j.append(c[5])


# In[10]:


f=file("requirement.txt")
s=f.read()
f.close()
lines=s.split('\n')
model=lines[4].split(':')[1]
if model=='1' :
    p=[1,1,1,500,0]
elif model=='2' :
    p=[1,1,1,0,60]
elif model=='3' :
    p=[2,0,0,0,0]
elif model=='4':
    p=[1,1,1,0,0]
elif model=='5':
    p=[0,1.5,1,0,0]
elif model=='6':
    p=[1,1.5,1,500,60]


# In[11]:


#for i in edges:
 #   k=p[0]*int(float(i[2]))+(p[1]*int(float(i[3]))+p[2]*int(float(i[4])))/2+p[3]*int(float(i[5]))+p[4]
  #  i.append(str(k))


# In[10]:


f=file('predicted_clean.csv','w')
f.write('origin,dest,time,depart,arrive,cancel,syn\n')
for i in edges:
    c=','.join(i)
    f.write(c+'\n')
f.close()

