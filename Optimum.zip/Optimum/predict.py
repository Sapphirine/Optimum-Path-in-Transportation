
from pyspark.ml import Pipeline, PipelineModel
from pyspark.ml.classification import RandomForestClassifier
from pyspark.ml.feature import IndexToString, StringIndexer, VectorIndexer
from pyspark.ml.evaluation import MulticlassClassificationEvaluator
from pyspark.sql import Row, SparkSession
from pyspark.ml.linalg import Vectors
import pandas
def trans(s):
    p=[]
    for i in s:
        p.append(float(i))
    return p


# Predict elapse

data=sc.textFile("predict_elapse.csv")
RDD=data.map(lambda x: trans(x.split(',')))
dfRDD=RDD.map(lambda x: Row(label=x[4],features=Vectors.dense([x[0],x[1],x[2],x[3]])))
df2=spark.createDataFrame(dfRDD)
te=df2
model=PipelineModel.load("ElapseModel")
pre=model.transform(te)
new=pre.select("features","predictedLabel")
new.toPandas().to_csv("predicted_elapse.csv")

# Predict arrive_delay

data=sc.textFile("predict_arrive.csv")
RDD=data.map(lambda x: trans(x.split(',')))
dfRDD=RDD.map(lambda x: Row(label=x[4],features=Vectors.dense([x[0],x[1],x[2],x[3]])))
df=spark.createDataFrame(dfRDD)
te=df
model=PipelineModel.load("ArriveModel")
pre=model.transform(te)
new=pre.select("features","predictedLabel")
new.toPandas().to_csv("predicted_arrive.csv")

# Predict depart_delay

data=sc.textFile("predict_delay.csv")
RDD=data.map(lambda x: trans(x.split(',')))
dfRDD=RDD.map(lambda x: Row(label=x[4],features=Vectors.dense([x[0],x[1],x[2],x[3]])))
df=spark.createDataFrame(dfRDD)
te=df
model=PipelineModel.load("DepartModel")
pre=model.transform(te)

new=pre.select("features","predictedLabel")
new.toPandas().to_csv("predicted_depart.csv")

# Predict cancel

data=sc.textFile("predict_cancel.csv")
RDD=data.map(lambda x: trans(x.split(',')))
dfRDD=RDD.map(lambda x: Row(label=x[4],features=Vectors.dense([x[0],x[1],x[2],x[3]])))
df=spark.createDataFrame(dfRDD)
te=df
model=PipelineModel.load("CancelModel")
pre=model.transform(te)
new=pre.select("features","predictedLabel")
new.toPandas().to_csv("predicted_cancel.csv")


